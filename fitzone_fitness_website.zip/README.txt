FITZONE FITNESS CENTER WEBSITE

Files:
- index.html: Main webpage structure and content.
- style.css: Responsive styling, layout, colors, and effects.

How to use:
1. Extract the ZIP file.
2. Keep index.html and style.css in the same folder.
3. Open index.html in a web browser.

Notes:
- The page uses online Unsplash images and Google Fonts, so an internet connection is needed for those assets.
- The registration form is a front-end demo. Connect a backend or form service to collect submissions.
- Replace sample trainer names, contact details, address, and membership prices with your real information.
